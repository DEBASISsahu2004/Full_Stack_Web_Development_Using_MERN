export const NOTES_DATA = "notes-data";
const types = {
    NOTES_DATA,
};

export default types;